"use strict";
exports.id = 277;
exports.ids = [277];
exports.modules = {

/***/ "./dist/stats.json":
/***/ ((module) => {

module.exports = JSON.parse('{"scripts":["main.7ca52294.js","runtime.7922fcc7.js","vendor.d7d64d10.js","components.b45a1d93.js"],"styles":["main.3a2c0f2e.css"]}');

/***/ })

};
;